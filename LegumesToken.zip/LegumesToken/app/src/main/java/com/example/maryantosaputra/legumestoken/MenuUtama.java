package com.example.maryantosaputra.legumestoken;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MenuUtama extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);
    }

    public void goInf (View view) {
        Intent goInf = new Intent(MenuUtama.this, Information.class);
        startActivity(goInf);
    }

    public void goTeam (View view) {
        Intent goTeam = new Intent(MenuUtama.this, Team.class);
        startActivity(goTeam);
    }

    public void goCom (View view) {
        Intent goCom = new Intent(MenuUtama.this, Community.class);
        startActivity(goCom);
    }

    public void goMar (View view) {
        Intent goMar = new Intent(MenuUtama.this, Market.class);
        startActivity(goMar);
    }
}
